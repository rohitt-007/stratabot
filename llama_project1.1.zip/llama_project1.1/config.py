API_DETAILS={
    "openai_api_key": "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"
}   